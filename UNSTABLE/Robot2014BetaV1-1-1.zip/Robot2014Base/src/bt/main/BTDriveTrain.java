/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTController.Axis;
import bt.storage.BTStorage;
import bt.storage.BTVector;

/**
 *
 * @author Dlock
 */
class BTDriveTrain {
    private BTStorage storage;
    private static final double B = Math.PI/4; 
    private static final double K = 1/Math.sin(B);
    
    public BTDriveTrain(BTStorage storage)
    {
        this.storage = storage;
    }
    public void update()
    {
        //tankDrive();
        fpsDrive();
    }
    private double calcMotorSpeed(double speed1, double speed2)
    {
        return 0;
    }
    private void fpsDrive()
    {
        double mag = getMagnitude(storage.con.LEFT_STICK_UP_DOWN, storage.con.RIGHT_STICK_LEFT_RIGHT);
        double angle = getAngle(storage.con.LEFT_STICK_UP_DOWN, storage.con.RIGHT_STICK_LEFT_RIGHT);
        double u = K*mag*Math.sin(angle+B);
        double v = K*mag*Math.sin(angle-B);
        u = Math.max(-1, Math.min(u, 1));
        v = Math.max(-1, Math.min(v, 1));
        storage.data.Rmotor1.setX(u);
        storage.data.Rmotor2.setX(u);
        storage.data.Lmotor1.setX(-v);
        storage.data.Lmotor2.setX(-v);
    }
    private double getAngle(Axis a, Axis b)
    {
        double aVal = a.getVal();
        double bVal = b.getVal();
        return BTVector.aTan(aVal/bVal);
    }
    private double getMagnitude(Axis a, Axis b)
    {
        double aVal = a.getVal();
        double bVal = b.getVal();
        aVal = Math.abs(aVal);
        bVal = Math.abs(bVal);
        return Math.max(aVal, bVal);
    }
    private void tankDrive()
    {
        double u = storage.con.RIGHT_STICK_UP_DOWN.getVal();
        double v = storage.con.LEFT_STICK_UP_DOWN.getVal();
        storage.data.Rmotor1.setX(u);
        storage.data.Rmotor2.setX(u);
        storage.data.Lmotor1.setX(-v);
        storage.data.Lmotor2.setX(-v);
    }
}
