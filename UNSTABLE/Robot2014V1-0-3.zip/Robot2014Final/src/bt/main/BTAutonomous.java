/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTStorage;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatNum;
import bt.storage.health.BTStatistic.BTStatString;

/**
 *
 * @author Dlock
 */
public class BTAutonomous {
    private final BTStorage storage;
    private double curDistance;
    private double startDistance;
    private double goToDistance = 30;
    private final double fudgeFactor = .1;
    private final double speed = .1;
    private boolean onStart = false;
    private boolean isManipMoving = true;
    private boolean isMoving = false;
    private boolean isShooting = false;
    private boolean isReloading = false;
    private long startTime;
    private BTStatGroup btAuto;
    private BTStatNum distance;
    private BTStatString stage;
    private double gotoHingeAngle = 0.75;
    private double curHingeAngle;
    
    
    public BTAutonomous(BTStorage storage)
    {
        this.storage = storage;
        startTime = 0;
        btAuto = new BTStatGroup("Autonomous");
        distance = btAuto.newNumStat("Distance of Robot: ", 0, true);
        stage = btAuto.newStringStat("AUTO MODE: ", "", true);
    }
    public void update()
    {
        curDistance = storage.data.ENCODER_LeftDrive.getDistance()-startDistance;
        updateManipView();
        updatePosition();
    }
    public void updateManipView() {
        double hingeSpeed = 0;
        if (isManipMoving) {
            stage.updateVal("Manip Moving");
            if (gotoHingeAngle < curHingeAngle - Constants.HINGE_FUDGE_FACTOR && storage.data.DI_minLimitSwitch.get()) {
                hingeSpeed = .25;
            } else if (gotoHingeAngle > curHingeAngle + Constants.HINGE_FUDGE_FACTOR && storage.data.DI_maxLimitSwitch.get()) {
                hingeSpeed = -.3;
            } else {
                storage.data.PISTON_LockAngle.extend();
                isManipMoving = false;
                isMoving = true;
            }
            storage.data.MOTOR_Hinge.setX(hingeSpeed);
        }
    }
    public void updatePosition()
    {
        if (isMoving) {
            stage.updateVal("Drive Moving");
            if (curDistance < goToDistance - fudgeFactor) {
                storage.data.MOTOR_L.setX(-speed);
                storage.data.MOTOR_R.setX(speed);
            } else if (curDistance > goToDistance + fudgeFactor) {
                storage.data.MOTOR_L.setX(speed);
                storage.data.MOTOR_R.setX(-speed);
            } else {
                storage.data.MOTOR_L.setX(0);
                storage.data.MOTOR_R.setX(0);
                if (!isReloading) {
                    isShooting = true;
                }
            }
        }
        distance.updateVal(curDistance);
        if (isShooting && startTime == 0)
        {
            startTime = System.currentTimeMillis();
        }
        if (isShooting)
        {
            stage.updateVal("Shooting");
            storage.data.PISTON_Collector.retract();
            if (System.currentTimeMillis()-startTime % 3000 == 0)
            {
                storage.data.PISTON_ManipRelease.retract();
                isShooting = false;
                isReloading = true;
            }
        }
        if (isReloading)
        {
            stage.updateVal("Reloading");
            storage.data.PISTON_Collector.extend();
            goToDistance = 12;
        }
        
    }
}
