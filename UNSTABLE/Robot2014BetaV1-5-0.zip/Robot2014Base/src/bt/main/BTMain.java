/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package bt.main;


import bt.storage.BTStorage;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatString;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class BTMain extends SimpleRobot {
    BTStorage storage;
    BTDriveTrain dt;
    BTStatString version;
    BTStatGroup btMain;
    Compressor comp;
    BTAutonomous auto;
    
    public void robotInit() {
        storage = new BTStorage();
        dt = new BTDriveTrain(storage);
        btMain = new BTStatGroup("BTMain");
        version = btMain.newStringStat("Version", "1.3.1", true);
        comp = new Compressor(Constants.COMP_SENSOR_PORT, Constants.COMP_RELAY_PORT);
        auto = new BTAutonomous(storage);
    }
    
    public void autonomous() {
        comp.start();
        storage.data.STIME = System.currentTimeMillis();
        while (isAutonomous())
        {
           storage.data.updateCycles();
           auto.update();
        }
    }

    public void operatorControl() {
        comp.start();
        storage.data.STIME = System.currentTimeMillis();
        while (isOperatorControl())
        {
            storage.data.updateCycles();
            dt.update();
        }
    }
    public void disabled() {
        comp.stop();
        if (Constants.DEBUG_DURING_DISABLED)
            storage.debug.printDebugWARNING();
    }
}
