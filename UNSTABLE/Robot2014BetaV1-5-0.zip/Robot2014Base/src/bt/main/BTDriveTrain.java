/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTStorage;
import bt.storage.BTVector;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatNum;

/**
 *
 * @author Dlock
 */
class BTDriveTrain {
    private BTStorage storage;
    private static final double B = Math.PI/4; 
    private static final double K = 1/Math.sin(B);
    private boolean tdrive = true;
    private final String HealthName = "BTDriveTrain";
    private BTStatGroup dtStats;
    private BTStatNum speedLeft;
    private BTStatNum speedRight;
    
    public BTDriveTrain(BTStorage storage)
    {
        this.storage = storage;
        dtStats = new BTStatGroup(HealthName);
        speedLeft = dtStats.newNumStat("Speed Left", 0, true);
        speedRight = dtStats.newNumStat("Speed Right", 0, true);
    }
    public void update()
    {
        fpsDrive();
        //updateSpeed();
    }
    private void updateSpeed()
    {
        speedLeft.updateVal(storage.data.left_encode.getRate());
        speedRight.updateVal(storage.data.right_encode.getRate());
    }
    private void fpsDrive()
    {
        double leftStickVal = storage.con.LEFT_STICK_UP_DOWN.getVal();
        double rightStickVal = storage.con.RIGHT_STICK_LEFT_RIGHT.getVal();
        
        double mag = getMagnitude(leftStickVal, rightStickVal);
        double angle = getAngle(leftStickVal, rightStickVal);
        double u = K*mag*Math.sin(angle+B);
        double v = K*mag*Math.sin(angle-B);
        u = Math.max(-1, Math.min(u, 1));
        v = Math.max(-1, Math.min(v, 1));
        storage.data.Rmotor1.setX(v);
        storage.data.Rmotor2.setX(v);
        storage.data.Lmotor1.setX(-u);
        storage.data.Lmotor2.setX(-u);
    }
    private double getAngle(double aVal, double bVal)
    {
        if (bVal == 0) {
            return aVal < 0 ? -Math.PI/2 : Math.PI/2;
        }
        double angle =  BTVector.aTan(aVal/bVal);
        if (bVal < 0)
            return Math.PI+angle;
        return angle;
    }
    private double getMagnitude(double aVal, double bVal)
    {
        aVal = Math.abs(aVal);
        bVal = Math.abs(bVal);
        return Math.max(aVal, bVal);
    }
    private void tankDrive()
    {
        double u = storage.con.RIGHT_STICK_UP_DOWN.getVal();
        double v = storage.con.LEFT_STICK_UP_DOWN.getVal();
        u = calcVelocity(u);
        v = calcVelocity(v);
        storage.data.Rmotor1.setX(u);
        storage.data.Rmotor2.setX(u);
        storage.data.Lmotor1.setX(-v);
        storage.data.Lmotor2.setX(-v);
    }
    private double calcVelocity(double x)
    {
        return x*Math.abs(x);
    }
}
