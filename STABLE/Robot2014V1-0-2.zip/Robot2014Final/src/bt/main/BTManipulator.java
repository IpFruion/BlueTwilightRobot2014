/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTStorage;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatBoolean;
import bt.storage.health.BTStatistic.BTStatNum;
import bt.storage.health.BTStatistic.BTStatString;

/**
 *
 * @author Programming Team GURUS
 */
public class BTManipulator {

    private final BTStorage storage;
    private static final double POT_ANGLE_CALC = 360 / 5.0;
    private static final double HINGE_LIMIT_MAX = 1.27;
    private static final double HINGE_LIMIT_MIN = 0;
    private static final double PASS_SPEED = 1;
    private static final double COLLECT_SPEED = .5;
    private static final double DPAD_ADJUSTMENTS = 1;
    private static final double RELOAD_TIME = 2000;
    private static final double RELOADING_DISTANCE = 24;
    private static final double MANIP_WINCH_MIN = 0;
    private static final double MANIP_WINCH_MAX = 48;
    private static final double MANIP_SPEED = .8;
    private static final double MANIP_LOW_SPEED = .1;
    private static final double fudgeFactorDpad = .05;
    private static final double fudgeFactorRightStick = .1;
    private static final double PITCH_SHOOTING = 0.75;
    private static final double PITCH_DOWN = 0;
    private static final double PITCH_UP = 4.0;
    private static final double TRUSS_POSITION = (MANIP_WINCH_MAX - RELOADING_DISTANCE) / 2.0 + RELOADING_DISTANCE;
    private static final double SWEET_SPOT_POSITION = (MANIP_WINCH_MAX - RELOADING_DISTANCE) * (3.0 / 4.0) + RELOADING_DISTANCE;
    private boolean isAtPosition;
    private boolean isReloading;
    private boolean isShooting;
    private boolean ballIN;
    private boolean isCollectorOpen;
    private boolean dpadPressed;
    private double timeOfShot;
    private double goToDistance;
    private double curDistance;
    private double gotoHingeAngle;
    private boolean hingeLimitSwitch;
    private boolean isHingeMoving;

    private final String HealthName;
    private final BTStatGroup manipStats;
    private final BTStatNum curDisStat;
    private final BTStatNum goToDisStat;
    private final BTStatNum curHingeAngleStat;
    private final BTStatNum goToHingeAngleStat;
    private final BTStatString shotPowerStat;
    private final BTStatBoolean canShootStat;
    private final BTStatNum hingeAngleStat;
    private final BTStatNum timeToReloadStat;
    private final BTStatBoolean isAtPositionStat;
    private final BTStatString[] debugStats;

    public BTManipulator(BTStorage storage) {
        this.storage = storage;
        HealthName = "BTManipulator";
        manipStats = new BTStatGroup(HealthName);

        debugStats = new BTStatString[20];
        debugStats[0] = manipStats.newStringStat("DEBUG: " + HealthName + " DI-LimitSwitch Max : " + Constants.MAX_LIMIT_SWITCH_PORT, "", Constants.DEBUGMODE);
        debugStats[1] = manipStats.newStringStat("DEBUG: " + HealthName + " Hinge POT : " + Constants.HINGE_MOTOR_PORT, "", Constants.DEBUGMODE);
        debugStats[2] = manipStats.newStringStat("DEBUG: " + HealthName + " Collector Motor : " + Constants.COLLECTOR_MOTOR_PORT, "", Constants.DEBUGMODE);
        debugStats[3] = manipStats.newStringStat("DEBUG: " + HealthName + " Collector Piston : E: " + Constants.COLLECTOR_PISTON_EXTEND_PORT + " R: " + Constants.COLLECTOR_PISTON_RETRACT_PORT, "", Constants.DEBUGMODE);
        debugStats[4] = manipStats.newStringStat("DEBUG: " + HealthName + " DI-LimitSwitch Min : " + Constants.MIN_LIMIT_SWITCH_PORT, "", Constants.DEBUGMODE);
        debugStats[5] = manipStats.newStringStat("DEBUG: " + HealthName + " Hinge Moving?", "", Constants.DEBUGMODE);
        debugStats[6] = manipStats.newStringStat("DEBUG: " + HealthName + " DI-LimitSwitch Winch : " + Constants.WINCH_LIMIT_SWITCH_PORT, "", Constants.DEBUGMODE);
        debugStats[7] = manipStats.newStringStat("DEBUG: " + HealthName + " isShooting: ", "", Constants.DEBUGMODE);
        debugStats[8] = manipStats.newStringStat("DEBUG: " + HealthName + " isReloading: ", "", Constants.DEBUGMODE);
        debugStats[9] = manipStats.newStringStat("DEBUG: " + HealthName + " isCollecting: ", "", Constants.DEBUGMODE);
        debugStats[10] = manipStats.newStringStat("DEBUG: " + HealthName + " isAtPosition ", "", Constants.DEBUGMODE);
        curDisStat = manipStats.newNumStat("Current Distance ", 0, true);
        curHingeAngleStat = manipStats.newNumStat("Current Hinge Angle", 0, true);
        goToHingeAngleStat = manipStats.newNumStat("GoTo Hinge Angle", 0, true);
        shotPowerStat = manipStats.newStringStat("Shot Power", "OFF", true);
        canShootStat = manipStats.newBoolStat("Can Shoot", false, true);
        hingeAngleStat = manipStats.newNumStat("Hinge Angle", 0, true);
        timeToReloadStat = manipStats.newNumStat("Time To Reload", 0, true);
        goToDisStat = manipStats.newNumStat("GoTo Distance", 0, true);
        isAtPositionStat = manipStats.newBoolStat("Is Retracted", false, true);
        isReloading = false;
        isShooting = false;
        ballIN = false;
        isCollectorOpen = false;
        isAtPosition = false;
        dpadPressed = false;
        timeOfShot = 0;
        curDistance = 0;
        goToDistance = 0;

        gotoHingeAngle = HINGE_LIMIT_MAX;
        hingeLimitSwitch = true;
        isHingeMoving = false;

        storage.data.PISTON_ManipRelease.extend();
        storage.data.PISTON_Collector.retract();
        storage.debug.write(Constants.DebugLocation.BTManipulator, Constants.Severity.INFO, "BTManipulator Inited");
    }

    public void update() {
        ballIN = false;
        //ballIN = storage.data.ballDetection.get();
        updateManipView();
        updateCollector();
        updateShooter();
        updateKickerLimit();
        updateShotPower();
        //updateKickerPosition();
        //updateKickerMotors();
    }

    private void updateManipView() {
        double curHingeAngle = -(storage.data.POT_Hinge.get() - 5);
        double conVal = storage.con.RIGHT_STICK_UP_DOWN.getVal();
        double hingeSpeed = 0;

        if (storage.con.LEFT_BUMPER_BUTTON.getLeadingEdge()) {
            gotoHingeAngle = PITCH_SHOOTING;
            hingeLimitSwitch = false;
            isHingeMoving = true;
        }
        if (storage.con.TRIGGER.getVal() == Constants.LEFT_TRIGGER) {
            hingeLimitSwitch = true;
            gotoHingeAngle = HINGE_LIMIT_MIN;
            isHingeMoving = true;
        }
        if (storage.con.BACK_BUTTON.getLeadingEdge()) {
            gotoHingeAngle = HINGE_LIMIT_MAX;
            hingeLimitSwitch = true;
            isHingeMoving = true;
        }
        if (isHingeMoving) {
            storage.data.PISTON_LockAngle.retract();
            if (hingeLimitSwitch) {
                if (gotoHingeAngle == HINGE_LIMIT_MIN && storage.data.DI_minLimitSwitch.get()) {
                    hingeSpeed = .25;
                } else if (gotoHingeAngle == HINGE_LIMIT_MAX && storage.data.DI_maxLimitSwitch.get()) {
                    hingeSpeed = -.3;
                } else {
                    isHingeMoving = false;
                }
            } else if (gotoHingeAngle > HINGE_LIMIT_MIN && gotoHingeAngle < HINGE_LIMIT_MAX) {
                if (gotoHingeAngle < curHingeAngle - Constants.HINGE_FUDGE_FACTOR && storage.data.DI_minLimitSwitch.get()) {
                    hingeSpeed = .25;
                } else if (gotoHingeAngle > curHingeAngle + Constants.HINGE_FUDGE_FACTOR && storage.data.DI_maxLimitSwitch.get()) {
                    hingeSpeed = -.3;
                } else {
                    storage.data.PISTON_LockAngle.extend();
                    isHingeMoving = false;
                }
            }
        }

        //TODO: set motors to hingeSpeed
        if (isHingeMoving) {
            storage.data.MOTOR_Hinge.setX(hingeSpeed);
        } else {
            storage.data.MOTOR_Hinge.setX(0);
        }

//        if (curHingeAngle < HINGE_LIMIT_MAX+Constants.HINGE_FUDGE_FACTOR && curHingeAngle > HINGE_LIMIT_MIN-Constants.HINGE_FUDGE_FACTOR && !isReloading && !isShooting)
//        {
//            if (conVal < fudgeFactorRightStick  && conVal > -fudgeFactorRightStick)
//            {
//                storage.data.MOTOR_Hinge.setX(0);
//            }
//            else
//            {
//                storage.data.MOTOR_Hinge.setX(-conVal/4);
//            }
//        }
//        else
//        {
//            storage.data.MOTOR_Hinge.setX(0);
//        }
        debugStats[0].updateVal("" + storage.data.DI_maxLimitSwitch.get());
        debugStats[4].updateVal("" + storage.data.DI_minLimitSwitch.get());
        debugStats[1].updateVal("" + storage.data.POT_Hinge.get());
        debugStats[5].updateVal("" + isHingeMoving);
        curHingeAngleStat.updateVal(curHingeAngle);
        goToHingeAngleStat.updateVal(gotoHingeAngle);
    }

    private void updateCollector() {
        if (storage.con.RIGHT_BUMPER_BUTTON.getBoolVal()) {
            storage.data.MOTOR_Collector.setX(-PASS_SPEED);
        } else if (storage.con.TRIGGER.getVal() == Constants.RIGHT_TRIGGER && !isShooting && !isReloading) {
            storage.data.MOTOR_Collector.setX(COLLECT_SPEED);
        } else {
            storage.data.MOTOR_Collector.setX(0);
        }
        if (storage.con.A_BUTTON.getLeadingEdge()) {
            isCollectorOpen = true;
        }
        if (storage.con.B_BUTTON.getLeadingEdge()) {
            isCollectorOpen = false;
        }
        if (isCollectorOpen) {
            storage.data.PISTON_Collector.extend();
        } else if (!isShooting && !isReloading) {
            storage.data.PISTON_Collector.retract();
        }
        if (isReloading) {
            storage.data.PISTON_Collector.retract();
        }
        debugStats[2].updateVal("" + storage.data.MOTOR_Collector.getX());
        debugStats[3].updateVal("" + storage.data.PISTON_Collector.isExtended());
        debugStats[9].updateVal("" + isCollectorOpen);

    }

    private void updateShooter() {
        boolean canFire = canShoot();
        if (isShooting) {
            timeToReloadStat.updateVal(timeOfShot + RELOAD_TIME - System.currentTimeMillis());
        } else {
            timeToReloadStat.updateVal(0);
        }
        if (canFire && storage.con.START_BUTTON.getLeadingEdge()) {
            storage.data.PISTON_ManipRelease.retract();
            isShooting = true;
            timeOfShot = System.currentTimeMillis();
        }
        if (isShooting && System.currentTimeMillis() - RELOAD_TIME > timeOfShot) {
            storage.data.PISTON_ManipRelease.extend();
            isShooting = false;
            isReloading = true;
        }
        canShootStat.updateVal(canFire);
    }

    public boolean canShoot() {
        if (isCollectorOpen && !isShooting && !isReloading && isAtPosition) {
            return true;
        }
        return false;
    }

    private void updateKickerPositionEncode() {
        boolean isAtEnd = false;
        boolean isAtBeginning = false;
        double dpadVal;

        curDistance = storage.data.ENCODER_ManipWinch.getDistance();
        dpadVal = storage.con.DPAD_LEFT_RIGHT.getVal();
        if (curDistance < RELOADING_DISTANCE) {
            isAtBeginning = true;
            isReloading = true;
        }
        if (curDistance > MANIP_WINCH_MAX) {
            isAtEnd = true;
        }

        if (dpadVal == Constants.LEFT_DPAD && !isAtBeginning && !dpadPressed) {
            goToDistance -= DPAD_ADJUSTMENTS;
            dpadPressed = true;
        } else if (dpadVal == Constants.RIGHT_DPAD && !isAtEnd && !dpadPressed) {
            goToDistance += DPAD_ADJUSTMENTS;
            dpadPressed = true;
        } else if (dpadVal <= fudgeFactorDpad && dpadVal >= -fudgeFactorDpad) {
            dpadPressed = false;
        }

        if (storage.con.Y_BUTTON.getBoolVal()) {
            goToDistance = SWEET_SPOT_POSITION;
        }

        if (isReloading) {
            goToDistance = RELOADING_DISTANCE;
        }
    }

    private void updateKickerMotorsEncode() {
        //TODO: add fudge factor
        if (curDistance < goToDistance && !isShooting) {
            storage.data.MOTOR_Winch.setX(MANIP_SPEED);
            isAtPosition = false;
        } else if (isShooting) {
            storage.data.MOTOR_Winch.setX(MANIP_LOW_SPEED);
        } else {
            storage.data.MOTOR_Winch.setX(0);
            isAtPosition = true;
            if (isReloading) {
                isReloading = false;
                storage.data.PISTON_Collector.retract();
            }
        }
        curDisStat.updateVal(curDistance);
        goToDisStat.updateVal(goToDistance);
    }

    private void updateKickerLimit() {
        if (storage.con.LEFT_STICK_BUTTON.getLeadingEdge()) {
            isReloading = true;
        }
        if (storage.con.RIGHT_STICK_BUTTON.getLeadingEdge())
        {
            isReloading = false;
        }
        curDistance = storage.data.ENCODER_ManipWinch.getDistance();
        if (isReloading) {
            if (storage.data.DI_winchLimit.get()) {
                storage.data.MOTOR_Winch.setX(MANIP_SPEED);
            } else {
                storage.data.MOTOR_Winch.setX(0);
                isReloading = false;
                isCollectorOpen = false;
            }
        }
        if (storage.data.DI_winchLimit.get()) {
            isAtPosition = false;
        } else {
            isAtPosition = true;
        }
        if (isShooting)
        {
            storage.data.MOTOR_Winch.setX(MANIP_LOW_SPEED);
        }
        isAtPositionStat.updateVal(isAtPosition);
        debugStats[6].updateVal("" + storage.data.DI_winchLimit.get());
        debugStats[7].updateVal("" + isShooting);
        debugStats[8].updateVal("" + isReloading);
        debugStats[10].updateVal("" + isAtPosition);
        curDisStat.updateVal(curDistance);
    }

    private void updateShotPower() {
        if (curDistance > RELOADING_DISTANCE && curDistance <= TRUSS_POSITION) {
            shotPowerStat.updateVal("Low");
        } else if (curDistance > TRUSS_POSITION && curDistance <= SWEET_SPOT_POSITION) {
            shotPowerStat.updateVal("Medium");
        } else if (curDistance > TRUSS_POSITION && curDistance <= MANIP_WINCH_MAX) {
            shotPowerStat.updateVal("High");
        } else {
            shotPowerStat.updateVal("NOT BALLIN");
        }
    }
}
