/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTStorage;
import bt.storage.BTVector;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatNum;
import bt.storage.health.BTStatistic.BTStatString;

/**
 *
 * @author Dlock
 */
class BTDriveTrain {
    private final BTStorage storage;
    private static final double B = Math.PI/4; 
    private static final double K = 1/Math.sin(B);
    private final double sonarFudgeFactor = 10;
    private final boolean tdrive = true;
    private boolean isLiningUp = false;
    private final String HealthName = "BTDriveTrain";
    private final BTStatGroup dtStats;
    private final BTStatString lineUp;
    private final BTStatNum speedLeft;
    private final BTStatNum speedRight;
    private final BTStatNum sonarSensor;
    
    public BTDriveTrain(BTStorage storage)
    {
        this.storage = storage;
        dtStats = new BTStatGroup(HealthName);
        
        speedLeft = dtStats.newNumStat("Speed Left", 0, true);
        speedRight = dtStats.newNumStat("Speed Right", 0, true);
        sonarSensor = dtStats.newNumStat("Sonar Distance", 0, true);
        
        lineUp = dtStats.newStringStat("Lineup Status", "", false);
        storage.debug.write(Constants.DebugLocation.BTDriveTrain, Constants.Severity.INFO, "BTDriveTrain initiated successfully");
    }
    public void update()
    {
        fpsDrive();
        updateSpeed();
        if (storage.debug.TIME % 500 >= 0 && storage.debug.TIME % 500 <= 5)
        {
            sonarSensor.updateVal(storage.data.SONAR_Drive.getRawDisIN());
        }
    }
    public void updateLineup()
    {
        double leftSide;
        double rightSide = 0;
        double difference;
        if (storage.con.START_BUTTON.getLeadingEdge() == true)
        {
            isLiningUp = !isLiningUp;
        }
        if (isLiningUp)
        {
            leftSide = storage.data.SONAR_Drive.getDisINVolt();
            //rightSide = storage.data.rightSonar.getDisINVolt();
            difference = rightSide-leftSide;
//            if (rightSide/leftSide >= 0.3 || leftSide/rightSide >= 0.3)
//                return;
            double movement = 0;
            
            if (difference >= sonarFudgeFactor)
            {
                lineUp.updateVal("TURNING RIGHT");
//                storage.data.MOTOR_L.setX(.5);
//                storage.data.MOTOR_L2.setX(.5);
//                storage.data.MOTOR_R.setX(.5);
//                storage.data.MOTOR_R2.setX(.5);
                
            }
            else if (difference <= -sonarFudgeFactor)
            {
                lineUp.updateVal("TURNING LEFT");
//                storage.data.MOTOR_L.setX(-.5);
//                storage.data.MOTOR_L2.setX(-.5);
//                storage.data.MOTOR_R.setX(-.5);
//                storage.data.MOTOR_R2.setX(-.5);
            }
            else
            {
                lineUp.updateVal("ON TARGET");
//                storage.data.MOTOR_L.setX(0);
//                storage.data.MOTOR_L2.setX(0);
//                storage.data.MOTOR_R.setX(0);
//                storage.data.MOTOR_R2.setX(0);
                isLiningUp = false;
            }
        }
        lineUp.updateVal("NOT LINING UP");
    }
    private void updateSpeed()
    {
        speedLeft.updateVal(storage.data.ENCODER_LeftDrive.getRate());
        speedRight.updateVal(storage.data.ENCODER_RightDrive.getRate());
    }
    private void fpsDrive()
    {
        double leftStickVal = storage.con.LEFT_STICK_UP_DOWN.getVal();
        double rightStickVal = storage.con.RIGHT_STICK_LEFT_RIGHT.getVal();
        
        if (leftStickVal < Constants.CON_FUDGE_FACTOR || leftStickVal > -Constants.CON_FUDGE_FACTOR)
            leftStickVal = 0;
        if (rightStickVal < Constants.CON_FUDGE_FACTOR || rightStickVal > -Constants.CON_FUDGE_FACTOR)
            rightStickVal = 0;
        
        double mag = getMagnitude(leftStickVal, rightStickVal);
        double angle = getAngle(leftStickVal, rightStickVal);
        double u = K*mag*Math.sin(angle+B);
        double v = K*mag*Math.sin(angle-B);
        u = Math.max(-1, Math.min(u, 1));
        v = Math.max(-1, Math.min(v, 1));
        
        storage.data.MOTOR_L.setX(v);
        storage.data.MOTOR_R.setX(-u);
        
        storage.debug.LeftVelocity.update(""+v);
        storage.debug.RightVelocity.update(""+u);
        storage.debug.LStick.update(""+leftStickVal);
        storage.debug.RStick.update(""+rightStickVal);
    }
    private double getAngle(double aVal, double bVal)
    {
        if (bVal == 0) {
            return aVal < 0 ? -Math.PI/2 : Math.PI/2;
        }
        double angle =  BTVector.aTan(aVal/bVal);
        if (bVal < 0)
            return Math.PI+angle;
        return angle;
    }
    private double getMagnitude(double aVal, double bVal)
    {
        aVal = Math.abs(aVal);
        bVal = Math.abs(bVal);
        return Math.max(aVal, bVal);
    }
    private void tankDrive()
    {
        double u = storage.con.RIGHT_STICK_UP_DOWN.getVal();
        double v = storage.con.LEFT_STICK_UP_DOWN.getVal();
        u = calcVelocity(u);
        v = calcVelocity(v);
        storage.data.MOTOR_R.setX(u);
        storage.data.MOTOR_L.setX(-v);
    }
    private double calcVelocity(double x)
    {
        return x*Math.abs(x);
    }
}
