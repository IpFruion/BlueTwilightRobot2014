/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.storage.profile;

/**
 *
 * @author Dlock
 */
public class ProfileHandler {
    
}
