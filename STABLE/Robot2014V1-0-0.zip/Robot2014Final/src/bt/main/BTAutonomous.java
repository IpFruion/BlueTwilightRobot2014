/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bt.main;

import bt.storage.BTStorage;

/**
 *
 * @author Dlock
 */
public class BTAutonomous {
    private final BTStorage storage;
    private double curDistance;
    private double startDistance;
    private double goToDistance = 3;
    private final double fudgeFactor = .1;
    private final double speed = .1;
    
    public BTAutonomous(BTStorage storage)
    {
        this.storage = storage;
        startDistance = storage.data.ENCODER_RightDrive.getDistance();
    }
    public void update()
    {
        curDistance = storage.data.ENCODER_RightDrive.getDistance()-startDistance;
        updatePosition();
    }
    public void updatePosition()
    {
        if (curDistance < goToDistance - fudgeFactor)
        {
            storage.data.MOTOR_L.setX(speed);
            storage.data.MOTOR_R.setX(-speed);
        }
        else if (curDistance > goToDistance + fudgeFactor)
        {
            storage.data.MOTOR_L.setX(-speed);
            storage.data.MOTOR_R.setX(speed);
        }
        else
        {
            storage.data.MOTOR_L.setX(0);
            storage.data.MOTOR_R.setX(0);
        }
    }
}
