/*----------------------------------------------------------------------------*/
/* Copyright (c) FIRST 2008. All Rights Reserved.                             */
/* Open Source Software - may be modified and shared by FRC teams. The code   */
/* must be accompanied by the FIRST BSD license file in the root directory of */
/* the project.                                                               */
/*----------------------------------------------------------------------------*/

package bt.main;


import bt.storage.BTStorage;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatNum;
import bt.storage.health.BTStatistic.BTStatString;
import edu.wpi.first.wpilibj.Compressor;
import edu.wpi.first.wpilibj.SimpleRobot;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the SimpleRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class BTMain extends SimpleRobot {
    BTStorage storage;
    BTDriveTrain dt;
    BTStatString version;
    BTStatGroup btMain;
    Compressor comp;
    BTAutonomous auto;
    BTManipulator shooter;
    BTStatNum compStat;
    String versionStr;
    
    public void robotInit() {
        storage = new BTStorage();
        versionStr = "shitBox (unstable)";
        dt = new BTDriveTrain(storage);
        btMain = new BTStatGroup("BTMain");
        version = btMain.newStringStat("Version", versionStr, true);
        comp = new Compressor(Constants.COMP_SENSOR_PORT, Constants.COMP_RELAY_PORT);
        auto = new BTAutonomous(storage);
        shooter = new BTManipulator(storage);
        storage.debug.write(Constants.DebugLocation.BTMain, Constants.Severity.INFO, "Robot Inited Version "+versionStr);
    }
    
    public void autonomous() {
        comp.start();
        storage.debug.STIME = System.currentTimeMillis();
        while (isAutonomous())
        {
           //auto.update();
        }
    }

    public void operatorControl() {
        comp.start();
        storage.debug.STIME = System.currentTimeMillis();
        storage.data.ENCODER_ManipWinch.start();
        storage.data.ENCODER_LeftDrive.start();
        storage.data.ENCODER_RightDrive.start();
        storage.data.ENCODER_ManipWinch.reset();
        while (isOperatorControl())
        {
            dt.update();
            shooter.update();
            if (storage.con.SELECT_BUTTON.getBoolVal())
            {
                storage.data.encoderReset();
            }
        }
    }
    public void disabled() {
        
        comp.stop();
        storage.data.encoderReset();
        if (Constants.DEBUG_DURING_DISABLED)
            storage.debug.printDebugWARNING();
    }
}
