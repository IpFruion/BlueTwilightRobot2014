/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package bt.main;

import bt.storage.BTStorage;
import bt.storage.Constants;
import bt.storage.health.BTStatGroup;
import bt.storage.health.BTStatistic.BTStatBoolean;
import bt.storage.health.BTStatistic.BTStatNum;
import bt.storage.health.BTStatistic.BTStatString;

/**
 *
 * @author Programming Team GURUS
 */
public class BTManipulator {
    private final BTStorage storage;
    private static final double POT_ANGLE_CALC = 360/5.0;
    private static final double HINGE_LIMIT_MAX = 2.4;
    private static final double HINGE_LIMIT_MIN = 1.1;
    private static final double PASS_SPEED = .5;
    private static final double COLLECT_SPEED = .2;
    private static final double DPAD_ADJUSTMENTS = 1;
    private static final double RELOAD_TIME = 5000;
    private static final double RELOADING_DISTANCE = 24;
    private static final double MANIP_WINCH_MIN = 0;
    private static final double MANIP_WINCH_MAX = 48;
    private static final double MANIP_SPEED = .5;
    private static final double fudgeFactorDpad = .05;
    private static final double fudgeFactorRightStick = .1;
    private static final double TRUSS_POSITION = (MANIP_WINCH_MAX-RELOADING_DISTANCE)/2.0 + RELOADING_DISTANCE;
    private static final double SWEET_SPOT_POSITION = (MANIP_WINCH_MAX-RELOADING_DISTANCE)*(3.0/4.0) + RELOADING_DISTANCE;
    private boolean isAtPosition;
    private boolean isReloading;
    private boolean isShooting;
    private boolean ballIN;
    private boolean isCollectorOpen;
    private boolean dpadPressed;
    private double timeOfShot;
    private double goToDistance;
    private double curDistance;
    private final BTStatGroup manipStats;
    private final BTStatNum curDisStat;
    private final BTStatNum goToDisStat;
    private final BTStatString shotPowerStat;
    private final BTStatBoolean canShootStat;
    private final BTStatNum hingeAngleStat;
    private final BTStatNum timeToReloadStat;

    
    public BTManipulator(BTStorage storage)
    {
        this.storage = storage;
        manipStats = new BTStatGroup("BTManipulator");
        curDisStat = manipStats.newNumStat("Current Distance ",0,true);
        shotPowerStat = manipStats.newStringStat("Shot Power", "OFF", true);
        canShootStat = manipStats.newBoolStat("Can Shoot", false, true);
        hingeAngleStat = manipStats.newNumStat("Hinge Angle", 0, true);
        timeToReloadStat = manipStats.newNumStat("Time To Reload", 0, true);
        goToDisStat = manipStats.newNumStat("GoTo Distance", 0, true);
        isReloading = false;
        isShooting = false;
        ballIN = false;
        isCollectorOpen = false;
        isAtPosition = false;
        dpadPressed = false;
        timeOfShot = 0;
        curDistance = 0;
        goToDistance = 0;
        storage.data.PISTON_ManipRelease.extend();
        storage.data.PISTON_Collector.retract();
        storage.debug.write(Constants.DebugLocation.BTManipulator, Constants.Severity.INFO, "BTManipulator Inited");
    }
    
    public void update()
    {
        ballIN = false;
        //ballIN = storage.data.ballDetection.get();
        updateManipView();
        updateCollector();
        //updateShooter();
        //updateKickerPosition();
        //updateKickerMotors();
        //updateShotPower();
        curDisStat.updateVal(storage.data.ENCODER_ManipWinch.getRaw());
        if (storage.con.B_BUTTON.getBoolVal())
        {
            storage.data.MOTOR_Winch.setX(.5);
        }
        if (storage.con.TRIGGER.getVal() == Constants.RIGHT_TRIGGER)
        {
            storage.data.PISTON_ManipRelease.retract();
        }
        else
        {
            storage.data.PISTON_ManipRelease.extend();
        }
        if (storage.con.Y_BUTTON.getBoolVal())
        {
            storage.data.MOTOR_Winch.setX(.1);
        }
        if (storage.con.X_BUTTON.getBoolVal())
        {
            storage.data.MOTOR_Winch.setX(0);
        }
    }
    
    private void updateManipView()
    {
        double hingeVal = storage.data.POT_Hinge.get();
        double conVal = storage.con.RIGHT_STICK_UP_DOWN.getVal();
        
        if (hingeVal < HINGE_LIMIT_MAX+Constants.HINGE_FUDGE_FACTOR && hingeVal > HINGE_LIMIT_MIN-Constants.HINGE_FUDGE_FACTOR && !isReloading && !isShooting)
        {
            if (conVal < fudgeFactorRightStick  && conVal > -fudgeFactorRightStick)
            {
                storage.data.MOTOR_Hinge_Left.setX(0);
                storage.data.MOTOR_Hinge_right.setX(0);
            }
            else
            {
                storage.data.MOTOR_Hinge_Left.setX(conVal/4);
                storage.data.MOTOR_Hinge_right.setX(-conVal/4);
            }
        }
        else
        {
            storage.data.MOTOR_Hinge_Left.setX(0);
            storage.data.MOTOR_Hinge_right.setX(0);
        }
        hingeAngleStat.updateVal(hingeVal);
    }
    
    private void updateCollector()
    {
        if (storage.con.LEFT_BUMPER_BUTTON.getBoolVal())
        {
            storage.data.MOTOR_Collector.setX(PASS_SPEED);
        }
        else if (storage.con.RIGHT_BUMPER_BUTTON.getBoolVal() && !ballIN && !isShooting && !isReloading)
        {
            storage.data.MOTOR_Collector.setX(-COLLECT_SPEED);
        }
        else
        {
            storage.data.MOTOR_Collector.setX(0);
        }
        
        if (storage.con.A_BUTTON.getBoolVal())
        {
            storage.data.PISTON_Collector.extend();
            isCollectorOpen = true;
        }
        else if (!isShooting && !isReloading)
        {
            storage.data.PISTON_Collector.retract();
            isCollectorOpen = false;
        }
    }
    
    private void updateShooter()
    {
        boolean canFire = canShoot();
        if (isShooting)
        {
            timeToReloadStat.updateVal(timeOfShot+RELOAD_TIME-System.currentTimeMillis());
        }
        else
        {
            timeToReloadStat.updateVal(0);
        }
        if (canFire && storage.con.TRIGGER.getVal() == Constants.RIGHT_TRIGGER)
        {
            storage.data.PISTON_ManipRelease.retract();
            isShooting = true;
            timeOfShot = System.currentTimeMillis();
        }
        if (isShooting && System.currentTimeMillis()-RELOAD_TIME > timeOfShot)
        {
            storage.data.PISTON_ManipRelease.extend();
            isShooting = false;
            isReloading = true;
        }
        if (isShooting && System.currentTimeMillis()-timeOfShot < timeOfShot)
        canShootStat.updateVal(canFire);
    }
    
    public boolean canShoot()
    {
        if (isCollectorOpen && !isShooting && ballIN && !isReloading && isAtPosition)
        {
            return true;
        }
        return false;
    }
    
    private void updateKickerPosition()
    {
        boolean isAtEnd = false;
        boolean isAtBeginning = false;
        double dpadVal;
        
        curDistance = storage.data.ENCODER_ManipWinch.getDistance();
        dpadVal = storage.con.DPAD_LEFT_RIGHT.getVal();
        if (curDistance < RELOADING_DISTANCE)
        {
            isAtBeginning = true;
            isReloading = true;
        }
        if (curDistance > MANIP_WINCH_MAX)
        {
            isAtEnd = true;
        }
        
        if (dpadVal == Constants.LEFT_DPAD && !isAtBeginning && !dpadPressed)
        {
            goToDistance -= DPAD_ADJUSTMENTS;
            dpadPressed = true;
        }
        else if (dpadVal == Constants.RIGHT_DPAD && !isAtEnd && !dpadPressed)
        {
            goToDistance += DPAD_ADJUSTMENTS;
            dpadPressed = true;
        }
        else if (dpadVal <= fudgeFactorDpad && dpadVal >= -fudgeFactorDpad)
        {
            dpadPressed = false;
        }
        
        if (storage.con.X_BUTTON.getBoolVal())
        {
            goToDistance = TRUSS_POSITION;
        }
        else if (storage.con.Y_BUTTON.getBoolVal())
        {
            goToDistance = SWEET_SPOT_POSITION;
        }
        else if (storage.con.B_BUTTON.getBoolVal())
        {
            goToDistance = MANIP_WINCH_MAX;
        }
        
        if (isReloading)
        {
            goToDistance = RELOADING_DISTANCE;
        }
    }
    
    private void updateKickerMotors()
    {
        //TODO: add fudge factor
        if (curDistance < goToDistance && !isShooting)
        {
            storage.data.MOTOR_Winch.setX(MANIP_SPEED);
            isAtPosition = false;
        }
        else 
        {
            storage.data.MOTOR_Winch.setX(0);
            isAtPosition = true;
            if (isReloading)
                isReloading = false;
        }
        curDisStat.updateVal(curDistance);
        goToDisStat.updateVal(goToDistance);
    }
    
    private void updateShotPower()
    {
        if (curDistance > RELOADING_DISTANCE && curDistance <= TRUSS_POSITION)
        {
            shotPowerStat.updateVal("Low");
        }
        else if (curDistance > TRUSS_POSITION && curDistance <= SWEET_SPOT_POSITION)
        {
            shotPowerStat.updateVal("Medium");
        }
        else if (curDistance > TRUSS_POSITION && curDistance <= MANIP_WINCH_MAX)
        {
            shotPowerStat.updateVal("High");
        }
        else
        {
            shotPowerStat.updateVal("NOT BALLIN");
        }
    }
}
